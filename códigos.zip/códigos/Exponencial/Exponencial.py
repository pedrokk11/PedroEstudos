def pesquisa_exponencial(lista, elemento):
    if lista[0] == elemento:
        return 0  # O elemento está na primeira posição da lista
    
    tamanho = len(lista)
    salto = 1
    while salto < tamanho and lista[salto] <= elemento:
        salto *= 2

    inicio = salto // 2
    fim = min(salto, tamanho - 1)
    
    return busca_binaria(lista, elemento, inicio, fim)


def busca_binaria(lista, elemento, inicio, fim):
    while inicio <= fim:
        meio = inicio + (fim - inicio) // 2
        
        if lista[meio] == elemento:
            return meio  # Elemento encontrado
        
        if lista[meio] < elemento:
            inicio = meio + 1
        else:
            fim = meio - 1
    
    return -1  # Elemento não encontrado


# Exemplo de uso:
lista_ordenada = [2, 4, 6, 8, 10, 12, 14, 16, 18, 20]
elemento_procurado = 12

resultado = pesquisa_exponencial(lista_ordenada, elemento_procurado)

if resultado == -1:
    print("Elemento não encontrado na lista")
else:
    print(f"O elemento {elemento_procurado} está na posição {resultado}")
