class TabelaDispersaoLinear:
    def __init__(self, tamanho):
        self.tamanho = tamanho
        self.tabela = [None] * tamanho
    
    def hash(self, chave):
        return chave % self.tamanho
    
    def inserir(self, chave, valor):
        posicao = self.hash(chave)
        if self.tabela[posicao] is None:
            self.tabela[posicao] = (chave, valor)
        else:
            # Lidar com colisões usando sondagem linear
            i = 1
            while self.tabela[(posicao + i) % self.tamanho] is not None:
                i += 1
            self.tabela[(posicao + i) % self.tamanho] = (chave, valor)
    
    def buscar(self, chave):
        posicao = self.hash(chave)
        i = 0
        while self.tabela[(posicao + i) % self.tamanho] is not None:
            if self.tabela[(posicao + i) % self.tamanho][0] == chave:
                return self.tabela[(posicao + i) % self.tamanho][1]
            i += 1
        return None
    
    def imprimir(self):
        for i in range(self.tamanho):
            if self.tabela[i] is not None:
                print(f"Posição {i}: {self.tabela[i]}")
            else:
                print(f"Posição {i}: Vazia")

# Exemplo de uso
tabela = TabelaDispersaoLinear(10)
tabela.inserir(123, "João")
tabela.inserir(456, "Maria")
tabela.inserir(789, "Pedro")
tabela.inserir(456, "Lucas")  # Colisão com a chave 456

tabela.imprimir()

print(tabela.buscar(123))  # Saída: João
print(tabela.buscar(456))  # Saída: Maria (primeira ocorrência da chave)
print(tabela.buscar(789))  # Saída: Pedro
print(tabela.buscar(999))  # Saída: None (chave não encontrada)
