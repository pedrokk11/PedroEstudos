def pesquisa_interpolacao(alunos, idade):
    baixo = 0
    alto = len(alunos) - 1

    while baixo <= alto and alunos[baixo]['idade'] <= idade <= alunos[alto]['idade']:
        posição = baixo + int(((float(alto - baixo) / (alunos[alto]['idade'] - alunos[baixo]['idade'])) * (idade - alunos[baixo]['idade'])))

        if alunos[posição]['idade'] == idade:
            return alunos[posição]

        if alunos[posição]['idade'] < idade:
            baixo = posição + 1
        else:
            alto = posição - 1

    return None


# Exemplo de uso
alunos = [
    {'nome': 'João', 'idade': 20},
    {'nome': 'Maria', 'idade': 25},
    {'nome': 'Pedro', 'idade': 30},
    {'nome': 'Ana', 'idade': 35},
    {'nome': 'Carlos', 'idade': 40},
]

idade_pesquisada = 20

aluno_encontrado = pesquisa_interpolacao(alunos, idade_pesquisada)

if aluno_encontrado:
    print(f"Aluno encontrado: {aluno_encontrado['nome']}")
else:
    print("Aluno não encontrado.")
