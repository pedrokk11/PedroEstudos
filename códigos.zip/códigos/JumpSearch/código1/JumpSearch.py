import math

def jump_search(arr, target):
    n = len(arr)
    step = int(math.sqrt(n))
    prev = 0

    # Encontrar o bloco onde o valor alvo pode estar presente
    while arr[min(step, n) - 1] < target:
        prev = step
        step += int(math.sqrt(n))
        if prev >= n:
            return -1

    # Realizar uma busca linear dentro do bloco encontrado
    while arr[prev] < target:
        prev += 1
        if prev == min(step, n):
            return -1

    # Se o elemento for encontrado, retornar o índice correspondente
    if arr[prev] == target:
        return prev

    return -1

# Exemplo de uso
arr = [1, 3, 5, 7, 9, 11, 13, 15, 17, 19]
target = 11

index = jump_search(arr, target)

if index != -1:
    print("Elemento encontrado no índice", index)
else:
    print("Elemento não encontrado")
