class No:
    def __init__(self, valor):
        # Cria os nó direita(filho nó) e esquerda(filho nó) e o nó valor (armazena o valor)
        self.valor = valor
        self.esquerda = None
        self.direita = None

def inserir(raiz, valor):
    if raiz is None:
        return No(valor)
    else:
        if valor < raiz.valor:
            raiz.esquerda = inserir(raiz.esquerda, valor)
        else:
            raiz.direita = inserir(raiz.direita, valor)
        return raiz

def imprimir_em_ordem(raiz):
    if raiz:
        imprimir_em_ordem(raiz.esquerda)
        print(raiz.valor, end=' ')
        imprimir_em_ordem(raiz.direita)

# Elementos a serem inseridos na árvore
elementos = [30, 15, 50, 25, 10, 31]

# Criando a raiz da árvore
raiz = None

# Inserindo os elementos na árvore
for elemento in elementos:
    raiz = inserir(raiz, elemento)

# Imprimindo os elementos em ordem
imprimir_em_ordem(raiz)
