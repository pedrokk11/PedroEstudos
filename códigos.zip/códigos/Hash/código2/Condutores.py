import pandas as pd


class Hash:
    def __init__(self, tam):
        self.tab = {}
        self.tam_max = tam

    def funcaohash(self, chave):
        v = self.hash_string(chave)  # Utiliza hash da string
        return v % self.tam_max

    def cheia(self):
        return len(self.tab) == self.tam_max

    def imprime(self):
        for i in self.tab:
            print("Hash[%d] = " % i, end="")
            print(self.tab[i])

    def apaga(self, chave):
        pos = self.busca(chave)
        if pos != -1:
            del self.tab[pos]
            print("-> Dado da posicao %d apagado" % pos)
        else:
            print("Item nao encontrado")

    def busca(self, chave):
        pos = self.funcaohash(chave)
        if self.tab.get(pos) == None:  # se esta posição não existe
            return -1  # saida imediata
        if self.tab[pos]['Condutores'] == chave:
            return pos
        return -1

    def insere(self, item):
        if self.cheia():
            print("-> ATENÇÃO Tabela Hash CHEIA")
            return
        pos = self.funcaohash(item['Condutores'])
        if self.tab.get(pos) == None:  # se posicao vazia
            self.tab[pos] = item
            print("-> Inserido HASH[%d]" % pos)
        else:  # se posicao ocupada
            print("-> Ocorreu uma colisao na posicao %d" % pos)

    def hash_string(self, s):
        # Função de hash simples para strings
        hash_value = 0
        for char in s:
            hash_value += ord(char)
        return hash_value


def ler_arquivo_csv(nome_arquivo):
    tab = Hash(13)  # Criando uma instância da classe Hash com tamanho 13 (exemplo)
    dados = pd.read_csv(nome_arquivo, encoding='utf-8', delimiter=',')  # Lê o arquivo CSV
    for _, row in dados.iterrows():
        item = {
            'Condutores': row['Condutores'],
            'A': row['A'],
            'AB': row['AB'],
            'AC': row['AC'],
            'ACC': row['ACC'],
            'ACCB': row['ACCB'],
            'ACCD': row['ACCD'],
            'AD': row['AD'],
            'AE': row['AE'],
            'B': row['B'],
            'C': row['C'],
            'D': row['D'],
            'E': row['E'],
            'CATEGORIA': row['CATEGORIA']
        }
        tab.insere(item)
    return tab


# Exemplo de uso
nome_arquivo = 'Condutores.csv'
tab = ler_arquivo_csv(nome_arquivo)
tab.imprime()
