# Implementação da Tabela Hash em Python

# Classe Aluno
class Aluno:
    def __init__(self, ra, nome):
        self.ra = ra
        self.nome = nome

# Tipo de dado abstrato - Tabela Hash
class TabelaHash:
    def __init__(self, max_items=100):
        self.max_items = max_items
        self.items = [None] * max_items

    def get_hash(self, ra):
        return ra % self.max_items

    def get(self, aluno):
        index = self.get_hash(aluno.ra)
        if self.items[index] is not None and self.items[index].ra == aluno.ra:
            return self.items[index]
        return None

    def insert(self, aluno):
        index = self.get_hash(aluno.ra)
        self.items[index] = aluno

# Exemplo de uso
tabela = TabelaHash(max_items=10)

aluno1 = Aluno(123, "João")
aluno2 = Aluno(456, "Maria")
aluno3 = Aluno(789, "Pedro")
aluno4 = Aluno(321, "Ana")
aluno5 = Aluno(654, "Carlos")
aluno6 = Aluno(987, "Laura")

tabela.insert(aluno1)
tabela.insert(aluno2)
tabela.insert(aluno3)
tabela.insert(aluno4)
tabela.insert(aluno5)
tabela.insert(aluno6)

# Buscando um aluno específico
ra_busca = 456
aluno_encontrado = tabela.get(Aluno(ra_busca, ""))
if aluno_encontrado is not None:
    print("Aluno encontrado:", aluno_encontrado.nome)
else:
    print("Aluno não encontrado.")
